# Adriel O'Malley's Portfolio
A Streamlit app showcasing my mini-projects in machine learning and data science, built to demonstrate practical knowledge of algorithms and real-world applications.
